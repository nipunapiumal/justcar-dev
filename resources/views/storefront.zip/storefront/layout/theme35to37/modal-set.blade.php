<!-- Preloader start -->
{{-- <div id="preLoader">
    <div class="loader">
        <div class="road">
            <div class="line"></div>
            <div class="line center-line"></div>
            <div class="line"></div>
            <div class="icon">
                <i class="fas fa-car"></i>
            </div>
        </div>
    </div>
</div> --}}
<!-- Preloader end -->