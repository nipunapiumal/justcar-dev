@extends('storefront.layout.theme29')
@section('page-title')
    {{ ucfirst($pageoption->name) }}
@endsection
@push('css-page')
    <style>
    </style>
@endpush
@section('content')

<!-- Start header section -->
<div class="inner-page-banner">
    <div class="banner-wrapper">
        <div class="container-fluid">
            <ul class="breadcrumb-list">
                <li>
                    <a href="{{ route('store.slug', $store->slug) }}">{{ __('Home') }}</a>
                </li>
                <li>{{ ucfirst($pageoption->name) }}</li>
            </ul>
            <div class="banner-main-content-wrap">
                <div class="row">
                    <div class="col-xl-6 col-lg-7 d-flex align-items-center">
                        <div class="banner-content">
                            <span class="sub-title">{{ ucfirst($pageoption->name) }}</span>
                            <h1>{{ ucfirst($pageoption->name) }}</h1>
                            {{-- <div class="customar-review">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <div class="review-top">
                                                <div class="logo">
                                                    <img src="{{ asset('assets/theme29to34/img/home1/icon/trstpilot-logo.svg') }}" alt="">
                                                </div>
                                                <div class="star">
                                                    <img src="{{ asset('assets/theme29to34/img/home1/icon/trustpilot-star.svg') }}" alt="">
                                                </div>
                                            </div>
                                            <div class="content">
                                                <ul>
                                                    <li>Trust Rating <span>5.0</span></li>
                                                    <li><span>2348</span> Reviews</li>
                                                </ul>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="review-top">
                                                <div class="logo">
                                                    <img src="{{ asset('assets/theme29to34/img/home1/icon/google-logo.svg') }}" alt="">
                                                </div>
                                                <div class="star">
                                                    <ul>
                                                        <li><i class="bi bi-star-fill"></i></li>
                                                        <li><i class="bi bi-star-fill"></i></li>
                                                        <li><i class="bi bi-star-fill"></i></li>
                                                        <li><i class="bi bi-star-fill"></i></li>
                                                        <li><i class="bi bi-star-half"></i></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <ul>
                                                    <li>Trust Rating <span>5.0</span></li>
                                                    <li><span>2348</span> Reviews</li>
                                                </ul>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div> --}}
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-5 d-lg-flex d-none align-items-center justify-content-end">
                        <div class="banner-img">
                            <img src="{{ asset('assets/theme29to34/img/inner-page/inner-banner-img.png') }}" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End header section -->
<!-- Start Wellcome Banner section -->
<div class="welcome-banner-section pb-100 pt-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="welcome-wrap text-center">
                    <div class="section-title1 text-center wow fadeInUp" data-wow-delay="200ms">
                        {{-- <span>(Since-1994)</span> --}}
                        <h2>{{ ucfirst($pageoption->name) }}</h2>
                    </div>
                    <div class="welcome-content wow fadeInUp" data-wow-delay="300ms">
                        <p>
                            {!! $pageoption->contents !!}
                        </p>
                    </div>
                    {{-- <div class="author-area wow fadeInUp" data-wow-delay="400ms">
                        <img src="assets/img/inner-page/signature.svg" alt="">
                        <h6>Natrison Mongla</h6>
                        <span>(CEO & Founder)</span>
                    </div> --}}
                </div>
                <div class="advertisement-block">
                    {!! \App\Models\Advertisement::getAdvertisement($store, 1) !!}
                </div>
            </div>
        </div>
    </div>
</div>

   
@endsection
